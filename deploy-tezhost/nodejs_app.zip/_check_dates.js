const mysql = require('mysql2/promise');
(async () => {
  const c = await mysql.createConnection({
    host: '127.0.0.1', port: 3306,
    user: 'ezeefloc_proderp', password: 'Memits@396', database: 'erp_mt_suite',
  });
  const TENANT = '11111111-1111-1111-1111-111111111111';

  console.log('=== Journal entries with entry_date (recent) ===');
  const [jes] = await c.query(`
    SELECT entry_number, entry_date, reference, status, source, created_at
    FROM journal_entries
    WHERE tenant_id = ? AND status = 'posted'
    ORDER BY created_at DESC
    LIMIT 25
  `, [TENANT]);
  console.table(jes);

  console.log('\n=== PINV-2026-00006 invoice dates ===');
  const [inv] = await c.query(
    "SELECT invoice_number, invoice_date, created_at FROM purchaseinvoices WHERE invoice_number = 'PINV-2026-00006'"
  );
  console.table(inv);

  console.log('\n=== Sales invoices (recent) dates ===');
  const [si] = await c.query(
    "SELECT invoice_number, invoice_date, created_at, journal_entry_id FROM sales_invoices WHERE tenant_id = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10",
    [TENANT]
  );
  console.table(si);

  console.log('\n=== Customer payments dates ===');
  const [cp] = await c.query(
    "SELECT payment_number, payment_date, created_at, journal_entry_id FROM customer_payments WHERE tenant_id = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10",
    [TENANT]
  );
  console.table(cp);

  console.log('\n=== Supplier payments dates ===');
  const [sp] = await c.query(
    "SELECT payment_number, payment_date, created_at, journal_entry_id FROM supplier_payments WHERE tenant_id = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10",
    [TENANT]
  );
  console.table(sp);

  await c.end();
})().catch(e => console.error(e.message));
